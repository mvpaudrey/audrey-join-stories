//
//  JoinStoriesSDK.h
//  JoinStoriesSDK
//
//  Created by Dimitri COMBE on 14/09/2021.
//

#import <Foundation/Foundation.h>

//! Project version number for JoinStoriesSDK.
FOUNDATION_EXPORT double JoinStoriesSDKVersionNumber;

//! Project version string for JoinStoriesSDK.
FOUNDATION_EXPORT const unsigned char JoinStoriesSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JoinStoriesSDK/PublicHeader.h>


